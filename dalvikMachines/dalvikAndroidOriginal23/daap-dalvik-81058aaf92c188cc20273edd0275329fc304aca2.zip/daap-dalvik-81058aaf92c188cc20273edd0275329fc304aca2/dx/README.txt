Home of Dalvik eXchange, the thing that takes in class files and
reformulates them for consumption in the VM. It also does a few other
things; use "dx --help" to see a modicum of self-documentation.
